# WiiPad

Usa il telefono Android come Wiimote virtuale (Bluetooth HID). Pensato per Mario Kart Wii:
sterzo inclinando il telefono come un volante, pulsanti 1/2/A/B/+/−/Home e croce direzionale,
touchpad per il puntatore nei menu, "Scuoti" per l'impennata.

## Requisiti
- Android 9 o superiore **con profilo HID Device funzionante** (non tutti i telefoni lo supportano:
  alcuni produttori lo disattivano).
- Android Studio (Koala o più recente). Apri la cartella `WiiPad`, lascia sincronizzare Gradle, esegui su telefono.

## Uso
1. Apri l'app, premi **AVVIA** e concedi i permessi Bluetooth + visibilità (5 min).
   Il telefono si rinomina temporaneamente "Nintendo RVL-CNT-01" (viene ripristinato con **Stop**).
2. Sulla Wii: avvia il gioco e quando chiede "premi 1 e 2" (o da Menu Wii → Opzioni → Impostazioni Wii →
   Controller → Wii Remote → Sincronizza) fa partire la ricerca. Il telefono deve comparire come Wiimote.
3. Tieni il telefono in orizzontale come un volante, tocca **Calibra** a volante dritto.
   Se sterza al contrario premi **Inverti**; regola la **Sensibilità**.
4. Mario Kart Wii: scegli il controllo "Wii Wheel / Wiimote orizzontale". Di solito 2 = accelera, 1 = freno.

## Se non si connette
- Premi **CoD** per provare altre varianti della classe del dispositivo (la Wii filtra in base a questa).
- Controlla il log nell'app: se compare una richiesta di pairing con PIN, l'app tenta il PIN
  (indirizzo della Wii invertito), ma Android spesso non lo consente alle app normali.
- Se il puntatore è invertito, o l'inclinazione non è quella giusta, i segni vanno aggiustati in
  `setSteering()` e `dots()` dentro `WiimoteEmulator.kt`.

## Stato del progetto
Scritto senza poterlo compilare né provare su una Wii reale: va considerato un primo prototipo.
Il protocollo del Wiimote (descriptor HID, report 0x20/0x21/0x22/0x3x, calibrazione EEPROM, IR base/esteso)
segue la documentazione di WiiBrew. I punti più incerti sono il riconoscimento da parte della Wii e il
pairing; se il telefono non regge, l'alternativa affidabile è un ESP32 che emula il Wiimote
(la parte di protocollo in `WiimoteEmulator.kt` si può riusare).
