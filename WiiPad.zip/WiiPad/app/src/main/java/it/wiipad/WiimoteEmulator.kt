package it.wiipad

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.util.concurrent.Executor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Maschere dei pulsanti nel formato "wire" del Wiimote (16 bit: byte0 | byte1 << 8). */
object Wm {
    const val LEFT = 0x0001
    const val RIGHT = 0x0002
    const val DOWN = 0x0004
    const val UP = 0x0008
    const val PLUS = 0x0010
    const val TWO = 0x0100
    const val ONE = 0x0200
    const val B = 0x0400
    const val A = 0x0800
    const val MINUS = 0x1000
    const val HOME = 0x8000
}

/**
 * Si finge un Wiimote (Bluetooth HID) usando l'API BluetoothHidDevice di Android 9+.
 * Gestisce i report di uscita della Wii (LED, modalita' report, lettura/scrittura memoria,
 * richiesta stato) e invia ~100 report/s con pulsanti, accelerometro e (opzionale) puntatore IR.
 */
@SuppressLint("MissingPermission")
class WiimoteEmulator(
    private val context: Context,
    private val onLog: (String) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    companion object {
        const val WIIMOTE_NAME = "Nintendo RVL-CNT-01"

        // Varianti del byte "subclass" (CoD minor). Il Wiimote reale ha CoD 0x002504.
        // Se la Wii non vede il telefono, prova le altre varianti dal pulsante in app.
        val SUBCLASSES = intArrayOf(0x04, 0x01, 0x08, 0x00)

        private const val G = 104.0 // conteggi per 1 g (10 bit): (0x9A - 0x80) * 4
        private const val ZERO = 512

        /** Descriptor HID del Wiimote (stessa struttura documentata su WiiBrew). */
        val DESCRIPTOR: ByteArray = buildDescriptor()

        private fun buildDescriptor(): ByteArray {
            val out = ArrayList<Byte>()
            fun add(vararg b: Int) = b.forEach { out.add(it.toByte()) }
            val outputs = listOf(
                0x10 to 1, 0x11 to 1, 0x12 to 2, 0x13 to 1, 0x14 to 1, 0x15 to 1,
                0x16 to 21, 0x17 to 6, 0x18 to 21, 0x19 to 1, 0x1A to 1,
            )
            val inputs = listOf(
                0x20 to 6, 0x21 to 21, 0x22 to 4, 0x30 to 2, 0x31 to 5, 0x32 to 10,
                0x33 to 17, 0x34 to 21, 0x35 to 21, 0x36 to 21, 0x37 to 21,
                0x3D to 21, 0x3E to 21, 0x3F to 21,
            )
            add(0x05, 0x01, 0x09, 0x05, 0xA1, 0x01)           // Generic Desktop / Game Pad / Application
            add(0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08)     // Logical 0..255, report size 8
            for ((id, n) in outputs) add(0x85, id, 0x95, n, 0x06, 0x00, 0xFF, 0x09, 0x01, 0x91, 0x00)
            for ((id, n) in inputs) add(0x85, id, 0x95, n, 0x06, 0x00, 0xFF, 0x09, 0x01, 0x81, 0x00)
            add(0xC0)
            return out.toByteArray()
        }
    }

    // ---- Stato scritto dalla UI (thread principale) --------------------------------------
    @Volatile var buttons = 0
    @Volatile var accX = ZERO
    @Volatile var accY = ZERO
    @Volatile var accZ = ZERO
    @Volatile var pointerX = 0.5f
    @Volatile var pointerY = 0.5f
    @Volatile var shakeUntil = 0L
    @Volatile var subclassVariant = 0

    // ---- Stato interno (solo thread "wiimote-tx") ------------------------------------------
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var originalName: String? = null
    private var registered = false

    private val thread = HandlerThread("wiimote-tx").apply { start() }
    private val handler = Handler(thread.looper)
    private val executor = Executor { handler.post(it) }

    private var reportMode = 0x30
    private var continuous = false
    private var leds = 0
    private var irOn = false
    private var irMode = 0
    private var speaker = false
    private var lastSent: ByteArray? = null
    private val eeprom = ByteArray(0x1700).also { initEeprom(it) }

    private fun initEeprom(m: ByteArray) {
        // Calibrazione accelerometro: zero = 0x80, 1g = 0x9A su ogni asse, LSB = 0, checksum.
        val cal = intArrayOf(0x80, 0x80, 0x80, 0x00, 0x9A, 0x9A, 0x9A, 0x00, 0x00)
        val sum = (cal.sum() + 0x55) and 0xFF
        for (base in intArrayOf(0x16, 0x20)) {
            cal.forEachIndexed { i, v -> m[base + i] = v.toByte() }
            m[base + 9] = sum.toByte()
        }
    }

    // ---- Controllo ---------------------------------------------------------------------------

    fun start(): Boolean {
        val ad = adapter
        if (ad == null || !ad.isEnabled) {
            onLog("Bluetooth non disponibile o spento")
            return false
        }
        if (originalName == null) originalName = ad.name
        ad.setName(WIIMOTE_NAME)
        val ok = ad.getProfileProxy(context, serviceListener, BluetoothProfile.HID_DEVICE)
        if (!ok) {
            onLog("Questo telefono non espone il profilo HID Device")
            return false
        }
        onStatus("Avvio...")
        return true
    }

    fun stop() {
        handler.post {
            handler.removeCallbacks(tick)
            try {
                host?.let { hid?.disconnect(it) }
                if (registered) hid?.unregisterApp()
            } catch (_: Exception) {
            }
            registered = false
            host = null
            hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
            hid = null
            originalName?.let { adapter?.setName(it) }
            originalName = null
            onStatus("Fermo")
        }
    }

    fun destroy() {
        stop()
        handler.postDelayed({ thread.quitSafely() }, 500)
    }

    /** Cambia variante CoD e si registra di nuovo. */
    fun cycleSubclass(): Int {
        subclassVariant = (subclassVariant + 1) % SUBCLASSES.size
        handler.post {
            if (registered) {
                hid?.unregisterApp()
                registered = false
            }
            register()
        }
        return SUBCLASSES[subclassVariant]
    }

    fun press(mask: Int, down: Boolean) {
        buttons = if (down) buttons or mask else buttons and mask.inv()
    }

    /** theta in radianti: 0 = volante dritto. Simula la gravita' vista dal Wiimote tenuto di lato. */
    fun setSteering(theta: Float) {
        val t = theta.toDouble()
        accX = (ZERO - G * cos(t)).roundToInt().coerceIn(0, 1023)
        accY = (ZERO + G * sin(t)).roundToInt().coerceIn(0, 1023)
        accZ = ZERO
    }

    fun shake(ms: Long = 450) {
        shakeUntil = SystemClock.uptimeMillis() + ms
    }

    // ---- Bluetooth ---------------------------------------------------------------------------

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = proxy as BluetoothHidDevice
                handler.post { register() }
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hid = null
                registered = false
                onStatus("Servizio HID perso")
            }
        }
    }

    private fun register() {
        val h = hid ?: return
        val sdp = BluetoothHidDeviceAppSdpSettings(
            WIIMOTE_NAME, WIIMOTE_NAME, "Nintendo",
            SUBCLASSES[subclassVariant].toByte(), DESCRIPTOR,
        )
        val ok = h.registerApp(sdp, null, null, executor, callback)
        onLog("registerApp(subclass=0x%02X): %s".format(SUBCLASSES[subclassVariant], ok))
    }

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@WiimoteEmulator.registered = registered
            onLog("App HID registrata: $registered")
            onStatus(if (registered) "Pronto: avvia la ricerca dalla Wii (1+2)" else "Non registrato")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    resetProtocolState()
                    onStatus("Connesso alla Wii")
                    onLog("Connesso a ${device.address}")
                    handler.removeCallbacks(tick)
                    handler.post(tick)
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host?.address == device.address) host = null
                    handler.removeCallbacks(tick)
                    onStatus("Disconnesso")
                    onLog("Disconnesso")
                }
                BluetoothProfile.STATE_CONNECTING -> onStatus("Connessione in corso...")
            }
        }

        override fun onGetReport(device: BluetoothDevice, type: Byte, id: Byte, bufferSize: Int) {
            hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ)
        }

        override fun onSetReport(device: BluetoothDevice, type: Byte, id: Byte, data: ByteArray) {
            handleOutput(id.toInt() and 0xFF, data)
            hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }

        override fun onInterruptData(device: BluetoothDevice, reportId: Byte, data: ByteArray) {
            handleOutput(reportId.toInt() and 0xFF, data)
        }

        override fun onVirtualCableUnplug(device: BluetoothDevice) {
            onLog("Virtual cable unplug")
        }
    }

    // ---- Protocollo Wiimote ----------------------------------------------------------------------

    private fun resetProtocolState() {
        reportMode = 0x30
        continuous = false
        irOn = false
        irMode = 0
        speaker = false
        lastSent = null
    }

    private fun send(id: Int, data: ByteArray) {
        val h = hid ?: return
        val d = host ?: return
        h.sendReport(d, id, data)
    }

    private fun btn(): ByteArray {
        val b = buttons
        return byteArrayOf((b and 0xFF).toByte(), ((b shr 8) and 0xFF).toByte())
    }

    private fun ack(reportId: Int, error: Int = 0) {
        val b = btn()
        send(0x22, byteArrayOf(b[0], b[1], reportId.toByte(), error.toByte()))
    }

    private fun sendStatus() {
        val b = btn()
        val flags = (leds shl 4) or (if (irOn) 0x08 else 0) or (if (speaker) 0x04 else 0)
        // bit1 = estensione collegata (0 = nessuna), bit0 = batteria scarica (0 = ok)
        send(0x20, byteArrayOf(b[0], b[1], flags.toByte(), 0, 0, 0xC8.toByte()))
    }

    private fun handleOutput(id: Int, d: ByteArray) {
        when (id) {
            0x10 -> Unit // solo vibrazione
            0x11 -> { leds = (d.getOrElse(0) { 0 }.toInt() shr 4) and 0x0F; onLog("LED: ${leds.toString(2)}"); ack(id) }
            0x12 -> {
                continuous = (d.getOrElse(0) { 0 }.toInt() and 0x04) != 0
                reportMode = d.getOrElse(1) { 0x30 }.toInt() and 0xFF
                lastSent = null
                onLog("Modalita' report 0x%02X (continuo=%s)".format(reportMode, continuous))
                ack(id)
            }
            0x13 -> { irOn = (d.getOrElse(0) { 0 }.toInt() and 0x04) != 0; ack(id) }
            0x1A -> { irOn = (d.getOrElse(0) { 0 }.toInt() and 0x04) != 0; ack(id) }
            0x14 -> { speaker = (d.getOrElse(0) { 0 }.toInt() and 0x04) != 0; ack(id) }
            0x19 -> ack(id)
            0x18 -> ack(id)
            0x15 -> sendStatus()
            0x16 -> writeMemory(d)
            0x17 -> readMemory(d)
            else -> onLog("Report non gestito 0x%02X".format(id))
        }
    }

    private fun readMemory(d: ByteArray) {
        if (d.size < 6) return
        val isReg = (d[0].toInt() and 0x04) != 0
        val addr = ((d[1].toInt() and 0xFF) shl 16) or ((d[2].toInt() and 0xFF) shl 8) or (d[3].toInt() and 0xFF)
        var size = ((d[4].toInt() and 0xFF) shl 8) or (d[5].toInt() and 0xFF)
        val b = btn()
        var off = 0
        while (size > 0) {
            val n = min(16, size)
            val out = ByteArray(21)
            out[0] = b[0]; out[1] = b[1]
            var err = 0
            if (!isReg) {
                val start = addr + off
                if (start + n <= eeprom.size) {
                    System.arraycopy(eeprom, start, out, 5, n)
                } else err = 8
            }
            // Registri (estensione/IR/speaker): rispondiamo con zeri.
            out[2] = (((n - 1) shl 4) or err).toByte()
            val a = (addr + off) and 0xFFFF
            out[3] = (a shr 8).toByte()
            out[4] = a.toByte()
            send(0x21, out)
            off += n
            size -= n
        }
    }

    private fun writeMemory(d: ByteArray) {
        if (d.size < 5) return
        val isReg = (d[0].toInt() and 0x04) != 0
        val addr = ((d[1].toInt() and 0xFF) shl 16) or ((d[2].toInt() and 0xFF) shl 8) or (d[3].toInt() and 0xFF)
        val size = d[4].toInt() and 0xFF
        val n = min(size, d.size - 5)
        if (!isReg) {
            if (addr + n <= eeprom.size) System.arraycopy(d, 5, eeprom, addr, n)
        } else if (addr == 0xB00033 && n > 0) {
            irMode = d[5].toInt() and 0xFF
            onLog("Modalita' IR: $irMode")
        }
        ack(0x16)
    }

    // ---- Invio periodico ---------------------------------------------------------------------

    private val tick = object : Runnable {
        override fun run() {
            if (host == null) return
            try {
                sendData()
            } catch (e: Exception) {
                onLog("Errore invio: ${e.message}")
            }
            handler.postDelayed(this, 10)
        }
    }

    private fun sendData() {
        val mode = reportMode
        val size = when (mode) {
            0x30 -> 2; 0x31 -> 5; 0x32 -> 10; 0x33 -> 17
            0x34, 0x35, 0x36, 0x37, 0x3D -> 21
            else -> return
        }
        val hasAccel = mode == 0x31 || mode == 0x33 || mode == 0x35 || mode == 0x37
        val out = ByteArray(size)

        var x = accX; var y = accY; var z = accZ
        val now = SystemClock.uptimeMillis()
        if (now < shakeUntil) {
            val s = sin(now * 2.0 * PI * 8.0 / 1000.0) * 2.2 * G
            x = (x + s).roundToInt().coerceIn(0, 1023)
            y = (y + s).roundToInt().coerceIn(0, 1023)
            z = (z + s).roundToInt().coerceIn(0, 1023)
        }

        val b = buttons
        var b0 = b and 0xFF
        var b1 = (b shr 8) and 0xFF
        if (hasAccel) {
            b0 = b0 or ((x and 3) shl 5)
            b1 = b1 or (((y shr 1) and 1) shl 5) or (((z shr 1) and 1) shl 6)
        }
        out[0] = b0.toByte()
        out[1] = b1.toByte()
        if (hasAccel) {
            out[2] = (x shr 2).toByte()
            out[3] = (y shr 2).toByte()
            out[4] = (z shr 2).toByte()
        }
        when (mode) {
            0x33 -> fillIrExtended(out, 5)
            0x36 -> fillIrBasic(out, 2)
            0x37 -> fillIrBasic(out, 5)
        }

        val last = lastSent
        if (continuous || last == null || !last.contentEquals(out)) {
            send(mode, out)
            lastSent = out
        }
    }

    /** Posizione dei due punti della sensor bar vista dalla "camera IR" (1024x768, immagine ruotata di 180°). */
    private fun dots(): IntArray? {
        if (!irOn) return null
        val cx = ((1f - pointerX) * 1023f).roundToInt()
        val cy = ((1f - pointerY) * 767f).roundToInt()
        val half = 90
        val x1 = cx - half
        val x2 = cx + half
        if (x1 !in 0..1023 || x2 !in 0..1023 || cy !in 0..767) return null
        return intArrayOf(x1, cy, x2, cy)
    }

    private fun fillIrExtended(o: ByteArray, at: Int) {
        for (i in 0 until 12) o[at + i] = 0xFF.toByte()
        val d = dots() ?: return
        for (k in 0..1) {
            val x = d[k * 2]; val y = d[k * 2 + 1]
            val p = at + k * 3
            o[p] = (x and 0xFF).toByte()
            o[p + 1] = (y and 0xFF).toByte()
            o[p + 2] = ((((y shr 8) and 3) shl 6) or (((x shr 8) and 3) shl 4) or 5).toByte()
        }
    }

    private fun fillIrBasic(o: ByteArray, at: Int) {
        for (i in 0 until 10) o[at + i] = 0xFF.toByte()
        val d = dots() ?: return
        val (x1, y1, x2, y2) = d.toList()
        o[at] = (x1 and 0xFF).toByte()
        o[at + 1] = (y1 and 0xFF).toByte()
        o[at + 2] = ((((y1 shr 8) and 3) shl 6) or (((x1 shr 8) and 3) shl 4) or
            (((y2 shr 8) and 3) shl 2) or ((x2 shr 8) and 3)).toByte()
        o[at + 3] = (x2 and 0xFF).toByte()
        o[at + 4] = (y2 and 0xFF).toByte()
    }
}
