package it.wiipad

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.atan2

@SuppressLint("MissingPermission", "SetTextI18n", "ClickableViewAccessibility")
class MainActivity : Activity(), SensorEventListener {

    private lateinit var emu: WiimoteEmulator
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var codBtn: Button
    private lateinit var invertBtn: Button

    private val logLines = ArrayDeque<String>()

    // Sterzo
    private var fx = 0f
    private var fy = 0f
    private var angle = 0f
    private var neutral = 0f
    private var neutralSet = false
    private var invert = false
    private var gain = 1.5f

    // ---- Ciclo di vita ---------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        emu = WiimoteEmulator(this, ::log, ::setStatus)
        setContentView(buildUi())
        registerReceiver(pairingReceiver, IntentFilter(BluetoothDevice.ACTION_PAIRING_REQUEST))
        log("Pronto. Premi AVVIA, poi sulla Wii: 1+2 / Controller")
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onPause() {
        super.onPause()
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(pairingReceiver) } catch (_: Exception) {}
        emu.destroy()
    }

    // ---- Sterzo con accelerometro ---------------------------------------------------------

    override fun onSensorChanged(e: SensorEvent) {
        fx = 0.8f * fx + 0.2f * e.values[0]
        fy = 0.8f * fy + 0.2f * e.values[1]
        angle = atan2(fy, fx)
        if (!neutralSet) { neutral = angle; neutralSet = true }
        var d = angle - neutral
        while (d > PI) d -= (2 * PI).toFloat()
        while (d < -PI) d += (2 * PI).toFloat()
        var t = d * gain
        val lim = (PI / 2).toFloat()
        t = t.coerceIn(-lim, lim)
        emu.setSteering(if (invert) -t else t)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    // ---- Permessi e avvio -----------------------------------------------------------------

    private fun hasBtPerms(): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        return listOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun startEmulation() {
        if (!hasBtPerms()) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 1,
            )
            return
        }
        if (emu.start()) {
            // Rende il telefono rilevabile per 5 minuti (massimo consentito).
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300),
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }) startEmulation()
        else log("Permessi Bluetooth negati")
    }

    // Se la Wii chiede un PIN (pairing legacy), proviamo a rispondere col suo indirizzo invertito.
    private val pairingReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val dev = deviceExtra(i) ?: return
            val variant = i.getIntExtra(BluetoothDevice.EXTRA_PAIRING_VARIANT, -1)
            log("Richiesta pairing da ${dev.address} (variante $variant)")
            if (variant == BluetoothDevice.PAIRING_VARIANT_PIN) {
                try {
                    val pin = dev.address.split(":").reversed().map { it.toInt(16).toByte() }.toByteArray()
                    log("setPin: ${dev.setPin(pin)}")
                } catch (e: Exception) {
                    log("setPin non consentito: ${e.javaClass.simpleName}")
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun deviceExtra(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)

    // ---- UI ------------------------------------------------------------------------------------

    private fun log(s: String) = runOnUiThread {
        logLines.addLast(s)
        while (logLines.size > 6) logLines.removeFirst()
        if (::logView.isInitialized) logView.text = logLines.joinToString("\n")
    }

    private fun setStatus(s: String) = runOnUiThread { if (::status.isInitialized) status.text = s }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun holdButton(label: String, mask: Int, size: Int = 72): Button = Button(this).apply {
        text = label
        textSize = 18f
        isAllCaps = false
        layoutParams = GridLayout.LayoutParams().apply { width = dp(size); height = dp(size); setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    emu.press(mask, true); v.isPressed = true
                    v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { emu.press(mask, false); v.isPressed = false }
            }
            true
        }
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun spacer(size: Int = 72) = View(this).apply {
        layoutParams = GridLayout.LayoutParams().apply { width = dp(size); height = dp(size) }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#12161C"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }

        // Sinistra: croce direzionale + - Home +
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val dpad = GridLayout(this).apply { columnCount = 3; rowCount = 3 }
        dpad.addView(spacer()); dpad.addView(holdButton("▲", Wm.UP)); dpad.addView(spacer())
        dpad.addView(holdButton("◀", Wm.LEFT)); dpad.addView(spacer()); dpad.addView(holdButton("▶", Wm.RIGHT))
        dpad.addView(spacer()); dpad.addView(holdButton("▼", Wm.DOWN)); dpad.addView(spacer())
        val sys = GridLayout(this).apply { columnCount = 3; rowCount = 1 }
        sys.addView(holdButton("−", Wm.MINUS, 56)); sys.addView(holdButton("Home", Wm.HOME, 56)); sys.addView(holdButton("+", Wm.PLUS, 56))
        left.addView(dpad); left.addView(sys)

        // Centro: stato, controlli, touchpad per il puntatore, log
        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f).apply { setMargins(dp(8), 0, dp(8), 0) }
        }
        status = TextView(this).apply { text = "Fermo"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(smallButton("AVVIA") { startEmulation() })
        row.addView(smallButton("Calibra") { neutral = angle; neutralSet = true; log("Sterzo azzerato") })
        invertBtn = smallButton("Inverti: no") {
            invert = !invert
            invertBtn.text = "Inverti: " + if (invert) "sì" else "no"
        }
        row.addView(invertBtn)
        codBtn = smallButton("CoD 0x04") {
            val v = emu.cycleSubclass(); codBtn.text = "CoD 0x%02X".format(v)
        }
        row.addView(codBtn)
        row.addView(smallButton("Scuoti") { emu.shake() })
        row.addView(smallButton("Stop") { emu.stop() })

        val sens = SeekBar(this).apply {
            max = 100; progress = 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { gain = 0.5f + p / 100f * 2.5f }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        val sensLabel = TextView(this).apply { text = "Sensibilità sterzo"; setTextColor(Color.LTGRAY); textSize = 11f }

        val pad = TextView(this).apply {
            text = "Touchpad puntatore (menu)"
            setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1E2630"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { setMargins(0, dp(6), 0, dp(6)) }
            setOnTouchListener { v, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                    emu.pointerX = (e.x / v.width).coerceIn(0f, 1f)
                    emu.pointerY = (e.y / v.height).coerceIn(0f, 1f)
                }
                true
            }
        }
        logView = TextView(this).apply { setTextColor(Color.parseColor("#8FA3B8")); textSize = 10f; maxLines = 6 }

        center.addView(status); center.addView(row); center.addView(sensLabel); center.addView(sens)
        center.addView(pad); center.addView(logView)

        // Destra: 1 2 / B A
        val right = GridLayout(this).apply { columnCount = 2; rowCount = 2 }
        right.addView(holdButton("1", Wm.ONE, 88)); right.addView(holdButton("2", Wm.TWO, 88))
        right.addView(holdButton("B", Wm.B, 88)); right.addView(holdButton("A", Wm.A, 88))

        root.addView(left); root.addView(center); root.addView(right)
        return root
    }
}
